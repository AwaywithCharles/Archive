# Island-Arcadia
<b>Backstory:</b> <i>The Name is unimportant. Names are like anchors, they ground you to your current reality.  Right now, Island Arcadia, is simply an island floating in the vast universe. The world can change; all from the toggle of a rock. </i>

Initially created and uploaded to VRChat on Friday 21 June 2019. 
Published to the Public saturday 22 June 2019.

For suggestions, recommendations, bug reports, and questions check out my discord: 

INW update
  
      - Pillow Chairs and lower
      - Pillows at lower
      - Particles at upper


<B>Update History:</B> 

6/27/2019 - 74.28
  - added small dead log to main island
  - hoverbike reset now working
  - Pillow fix
  - invisible chair at upper pillow

6/26/2019 - 72.69
  - Hoverbike Reset (still not workin)
  - Mirror on Secret island 1
  - Updated discription
  - Shaders on flowers
  - Toggle 2nd lighting (for desktop users when to dark)
  - repositioned dead log
  - slight ptimized some of the mirrors to turn off other mirrors
  - added pillows
  - toggled to start world with particles on

6/25/2019 - 72.67mb
  - Managed children/game object folders for islands and paths
  - added path for 2nd secret island along with island
  - fixed some rock interactions
  - set several rocks to static for baked lighting
  - switch to unity 2017.4.28f1
  - SDK updated to 2019.06.21.13.53_Public
  - adjusted main island 2nd mirror distance
  - Scattered some flowers on primary island
  - changed description
  
  
6/23/2019
  - added toggle light
  - removed all grass and switch to 5 small flowers for later implimination

6/22/2019
  - addedd 2nd mirror for other PC's
  - added hidden jump puzzle
  - added hidden island
  - added hidden hovebike
  - made whale actually swim instead of just floating
  
6/21/2019
  - Made Particles toggle
  - Made mirror toggle
  - added addition music on toggle
  - Added plants
